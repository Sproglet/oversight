#!/bin/sh -- #
# Convert script from DOS
true                            #

if [ $? != 0 ]; then            #
    set -e                      #
    sed 's/.$//' "$0" > /tmp/$$ #
    cat /tmp/$$ > "$0"          #
    rm /tmp/$$                  #
    exec /bin/sh "$0" "$@"      #
    exit                        #
fi                              #

VERSION=20090110-2
#Cant use named pipes due to blocking at script level
EXE=$0
while [ -L "$EXE" ] ; do
    EXE=$( ls -l "$EXE" | sed 's/.*-> //' )
done
HOME=$( echo $EXE | sed -r 's|[^/]+$||' )
HOME=$(cd "${HOME:-.}" ; pwd )
TVMODE=`cat /tmp/tvmode`
OWNER=nmt
GROUP=nmt
appname=oversight
CMD_BUF="$HOME/tmp/oversight.cmd"
LOCK="$HOME/tmp/oversight.lck"
CACHE_DIR=/tmp/oversight.cache
cd "$HOME"

NMT="$HOME/install.bin"
LISTEN() {
        date
        if [ -e "$LOCK" ] ; then
            pid=`cat "$LOCK"`
            if [ -d "/proc/$pid" ] ; then
                echo "locked by another process"
                exit;
            fi
        fi
        echo $$ > "$LOCK"

        if [ -e "$CMD_BUF.pending" ] ; then
            mv "$CMD_BUF.pending" "$CMD_BUF.live"
            while read prefix command ; do
                echo "$prefix[$command]"
                case "$prefix" in
                    oversight:) eval  "$command" ;;
                    *) echo "Ignoring [$command]" ;;
                esac
            done < "$CMD_BUF.live"
            rm -f "$CMD_BUF.live"
        fi

        rm -f "$LOCK"
}

ARGLIST() {
    ARGS=""
    for i in "$@" ; do
        case "$i" in
        *\'*)
            case "$i" in
            *\"*) ARGS=`echo "$ARGS" | sed -r 's/[][ *"()?!'"'"']/\\\1/g'` ;;
            *) ARGS="$ARGS "'"'"$i"'"' ;;
            esac
            ;;
        *) ARGS="$ARGS '$i'" ;;
        esac
    done
    echo "$ARGS"
}
SWITCHUSER() {
    if ! id | fgrep -q "($OWNER)" ; then
        u=$1
        shift;
        echo "[$USER] != [$u]"
        
        #Write args to a file. - probably a neater way...
        a="$0 $(ARGLIST "$@")"
        echo "CMD=$a"
        exec su $u -s /bin/sh -c "$a"
    fi
}

# Add command to the queue
SAY() {
    #Avoid blocking for pipe
    A="$(ARGLIST "$@")"
    echo "oversight: $A" >> "$CMD_BUF.pending"
    chown $OWNER:$GROUP "$CMD_BUF.pending"
}

PERMS() {
    chown $OWNER:$GROUP "$1" "$1"/*
}

HTML() {
    echo "<p>$@<p>"
}

site="http://prodynamic.co.uk/oversight-test"

UPGRADE() {
    OLDVERSION=`grep ^VERSION oversight.cgi | head -1 | sed 's/.*=//'`
    oldzipfile="oversight-$OLDVERSION.saved.zip" 
    oldtarfile="oversight-$OLDVERSION.saved.tar"  #zip not in firmware
    echo "<p>Start $1<p>"
    case "$1" in 
        CHECK)
            rm -f VERSION
            if ! wget -q -O VERSION "$site/VERSION" ; then
                echo ERROR > VERSION
                PERMS .
                exit 1
            fi
            ;;
        INSTALL)
            NEWVERSION=`cat VERSION`
            zipdir="$HOME/versions"
            newzipfile="oversight-$NEWVERSION.zip" 

            if [ ! -d "$zipdir" ] ; then mkdir p "$zipdir" ; fi
            PERMS .

            #Get new
            HTML Fetch $site/$newzipfile 
            rm -f "$zipdir/$newzipfile"
            if ! wget -q  -O "$zipdir/$newzipfile" "$site/$newzipfile" ; then
                echo "ERROR getting $site/$newzipfile" > VERSION;
                PERMS .
                exit 1
            fi

            #Backup
            #zip "$zipdir/$oldzipfile"  index.db* *.example *.cfg *.sh *.cgi *.bin
            #ln -sf "$zipdir/$oldzipfile" "$zipdir/undo.zip"

            HTML Backup old files
            tar cf "$zipdir/$oldtarfile"  index.db* *.example *.cfg *.sh *.cgi *.bin
            ln -sf "$zipdir/$oldtarfile" "$zipdir/undo.tar"

            HTML Unpack new files
            unzip -oq "$zipdir/$newzipfile"

            HTML Set Permissions
            PERMS "$zipdir"

            HTML Clear web cache
            CLEAR_CACHE

            HTML Upgrade Complete
            ;;

        UNDO)

            HTML Save current files
            #zip "$zipdir/$oldzipfile"  index.db* *.example *.cfg *.sh *.cgi *.bin
            tar cf "$zipdir/$oldtarfile"  index.db* *.example *.cfg *.sh *.cgi *.bin
            PERMS "$zipdir"

            HTML Restore last backup
            #zip -l "$zipdir/undo.zip"
            tar xf "$zipdir/undo.tar"

            HTML Set Permissions
            chown -R $OWNER:$GROUP .

            HTML Clear web cache
            CLEAR_CACHE
            HTML Undo Complete
            ;;
    esac
}

CLEAR_CACHE() {
    if [ -d "$CACHE_DIR" ] ; then rm -f -- "$CACHE_DIR"/* ; fi
    if [ -d "$CACHE_DIR.old" ] ; then rm -f -- "$CACHE_DIR.old"/* ; fi
}

CLEAR_CACHE_QUICK() {
    #If running from cgi need to be quick for nmt platform
    #Probably not necessary for size of nmt files.
    mkdir -p "$CACHE_DIR.old"
    mv "$CACHE_DIR"/* "$CACHE_DIR.old"/.
    chown -R nmt:nmt "$CACHE_DIR.old"
    SAY "$HOME/oversight.sh CLEAR_CACHE"
}

case "$1" in 
    REBOOTFIX)
        ln -sf "$HOME/$appname.cgi" /opt/sybhttpd/default/.
        "$NMT" NMT_CRON_ADD nmt "$appname" "* * * * * cd '$HOME' && './$appname.sh' LISTEN >/dev/null 2>&1 &"
        exit ;;
    LISTEN)
        if [ -e "$CMD_BUF.pending" ] ; then
            SWITCHUSER "$OWNER" "$@"
            LISTEN >> "$HOME/logs/listen.log" 2>&1 || rm -f "$LOCK"
        fi
        exit;;
    UNINSTALL)
        "$NMT" NMT_CRON_DEL nmt "$appname" 
        "$NMT" NMT_CRON_DEL root "$appname" 
        rm -f "/opt/sybhttpd/default/oversight.cgi" /tmp/oversight.constants "$CMD_BUF.pending" "$CMD_BUF.live"
        exit;;
    SAY)
        shift;
        SAY "$@"
        exit;;
    CLEAR_CACHE) CLEAR_CACHE ;;
    CLEAR_CACHE_QUICK) CLEAR_CACHE_QUICK;;
    UPGRADE) UPGRADE "$2" ;;
    *) echo "usage: $0 REBOOTFIX|LISTEN|SAY|UNINSTALL";;
esac
