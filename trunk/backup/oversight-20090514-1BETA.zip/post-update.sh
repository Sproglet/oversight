#!/bin/sh

#Update crontab
$APPDIR/oversight.sh REBOOTFIX
