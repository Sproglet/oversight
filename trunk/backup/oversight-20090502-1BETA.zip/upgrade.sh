#!/bin/sh -- #
# Convert script from DOS
true                            #

if [ $? != 0 ]; then            #
    set -e                      #
    sed 's/.$//' "$0" > /tmp/$$ #
    cat /tmp/$$ > "$0"          #
    rm /tmp/$$                  #
    exec /bin/sh "$0" "$@"      #
    exit                        #
fi                              #

VERSION=20090502-1BETA
#Cant use named pipes due to blocking at script level
EXE=$0
while [ -L "$EXE" ] ; do
    EXE=$( ls -l "$EXE" | sed 's/.*-> //' )
done
HOME=$( echo $EXE | sed -r 's|[^/]+$||' )
HOME=$(cd "${HOME:-.}" ; pwd )
TVMODE=`cat /tmp/tvmode`
OWNER=nmt
GROUP=nmt
cd "$HOME"

PERMS() {
    chown $OWNER:$GROUP "$1" "$1"/*
}

HTML() {
    echo "<p>$@<p>"
}


site="http://prodynamic.co.uk/nmt/"
backupdir="$HOME.backup_undo"

UPGRADE() {

    appname="$1"

    cd "$HOME"

    VER=VERSION.dl

    echo "<p>Start $1<p>"
    case "$2" in 
        check)
            rm -f $VER
            if ! wget -q -O $VER "$site/$appname/VERSION" ; then
                echo ERROR > $VER
                PERMS .
                exit 1
            fi
            ;;
        checkbeta)
            rm -f $VER
            if ! wget -q -O $VER "$site/$appname/VERSION-BETA" ; then
                echo ERROR > $VER
                PERMS .
                exit 1
            fi
            ;;
            #This is not a first time install but just to overwrite files with
            # downloaded ones. see install-cgi for first time install
        install)
            NEWVERSION=`cat $VER`
            tardir="$HOME/versions"
            newtgzfile="$appname-$NEWVERSION.tgz" 
            newtarfile="$appname-$NEWVERSION.tar" 

            if [ ! -d "$tardir" ] ; then mkdir p "$tardir" ; fi
            PERMS .

            #Get new
            HTML Fetch $site/$appname/$newtgzfile 
            rm -f -- "$tardir/$newtgzfile"
            if ! wget -q  -O "$tardir/$newtgzfile" "$site/$appname/$newtgzfile" ; then
                echo "ERROR getting $site/$appname/$newtgzfile" > $VER;
                PERMS .
                exit 1
            fi

            $HOME/gunzip.php "$tardir/$newtgzfile" "$tardir/$newtarfile"
            rm -f "$tardir/$newtgzfile"

            HTML Backup old files
            if [ -d "$backupdir" ] ; then
                if [ -d "$backupdir.2" ] ; then
                    rm -fr -- "$backupdir.2"
                fi
                mv "$backupdir" "$backupdir.2"
            fi
            cp -a "$HOME" "$backupdir"

            if [ -f post-update.sh ] ; then rm -f ./post-update.sh || true ; fi

            HTML Unpack new files
            tar xf "$tardir/$newtarfile"
            chown -R $OWNER:$GROUP .

            HTML Set Permissions
            PERMS "$tardir"

            HTML Post Update actions
            if [ -f post-update.sh ] ; then
                ./post-update.sh || true
                rm -f ./post-update.sh || true
            fi

            HTML Upgrade Complete
            ;;

        undo)

            if [ ! -d "$backupdir" ] ; then
                echo Cant undo : no folder "$backupdir"
                return 1;
            fi

            if [ -d "$backupdir.abort" ] ; then
                rm -fr -- "$backupdir.abort"
            fi

            mv "$HOME" "$backupdir.abort"
            mv "$backupdir" "$HOME"
            chown -R $OWNER:$GROUP .

            HTML Undo Complete
            ;;
    esac

}

logdir="$HOME/logs"

mkdir -p "$logdir"

set -x

UPGRADE "$@" > $logdir/upgrade.$$.log 2>&1

chown -R $OWNER:$GROUP $logdir

