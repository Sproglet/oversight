KDE Crystal Diamond
